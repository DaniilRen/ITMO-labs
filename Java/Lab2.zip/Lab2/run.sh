#!/bin/bash

# java -cp "out:lib/Pokemon.jar" Main   
java -jar lab2.jar